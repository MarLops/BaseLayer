
from sklearn.base import BaseEstimator
from inspect import signature
from abc import ABC,abstractmethod 


class SimpleLayerPipeline(BaseEstimator):
    """
    Layer to add any function to use in gridsearch or pipeline. Can only add one SimpleLayerPipeline in grid/pipeline

    """
    def __new__(cls,**paramets):
        if "function" in paramets:
            cls._function = dict()
            cls._function["fit"] = paramets["function"]
        return object.__new__(cls)

    def __init__(self,**paramets):
        """
        Start class to add in gridsearch/pipeline


        :paramets: dict with key as args of function
        paramets need to have key = function and the value equal
        the function

        The function receive the data as the first parameters
        """
        self._function_fit = dict()
        self._function_fit["fit"] = self._function["fit"]
        if "function" in paramets:
            del paramets['function']
        self.paramets = paramets

    def fit(self,X=None,y=None,**paramets):
        return self

    def partial_fit(self, X,y=None):
        if len(self.paramets) > 0:
            return self._function_fit["fit"](X,**self.paramets)
        return self._function_fit["fit"](X)

    def transform(self, X):
        return self.partial_fit(X)
        

    def get_params(self,deep=True):
        result =dict(signature(self._function_fit["fit"]).parameters.items())
        del result["X"]
        return {i:result[i].default for i in result}

    def set_params(self,**paramets):
        self.paramets = paramets
        
    

class LayerTransformSklearn(BaseEstimator,ABC):
    """
    Base class to add function to gridsearch/pipeline


    Need implement _function_fit(self,X,**kwargs)
    The argument X is the data
    The result of _function_fit need to be data
    """
    def __init__(self,**paramets):
        """
        Class to transform data inside of gridsearch/pipeline

        :paramets: kwargs to pass to _function_fit
        """
        self.paramets = paramets


    def fit(self,X=None,y=None,**paramets):
        return self

    def partial_transform(self, X,y=None):
        if len(self.paramets) > 0:
            return self._function_transform(X,**self.paramets)
        return self._function_transform(X)

    def transform(self, X):
        return self.partial_transform(X)

    def get_params(self,deep=True):
        result =dict(signature(self._function_transform).parameters.items())
        del result["X"]
        if "self" in result:
            del result['self']
        return {i:result[i].default for i in result}

    def set_params(self,**paramets):
        self.paramets = paramets

    @abstractmethod
    def _function_transform(self,X):
        pass

class LayerFitTransformSklearn(BaseEstimator,ABC):
    """
    Base class to add function to gridsearch/pipeline


    Need implement _function_fit(self,X,y,**kwargs) and _function_transform(self,X,**kwargs)
    The argument X is the data and y the target
    The result of _function_fit need to be dict that it will be pass to _function_transform
    The result of _function_transform need to be X
    """
    def __init__(self,**paramets):
        self.paramets = paramets


    def fit(self,X=None,y=None):
        self._paramets_after_fit = self.partial_fit(X,y)
        return self

    def partial_fit(self, X,y=None):
        if len(self.paramets) > 0:
            if "y" in self.paramets:
                del self.paramets
            return self._function_fit(X,y,**self.paramets)
        return self._function_fit(X,y)

    def transform(self, X):
        return self._function_transform(X,**self._paramets_after_fit)

    def get_params(self,deep=True):
        result =dict(signature(self._function_fit).parameters.items())
        del result["X"]
        if 'self' in result:
            del result['self']
        if 'y' in result:
            del result['y']
        return {i:result[i].default for i in result}

    def set_params(self,**paramets):
        self.paramets = paramets

    @abstractmethod
    def _function_fit(self,X,y):
        pass

    @abstractmethod
    def _function_transform(self,X,**kargs):
        pass
